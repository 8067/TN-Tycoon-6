/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file newgrf_town.cpp Implementation of the town part of NewGRF houses. */

#include "stdafx.h"
#include "debug.h"
#include "town.h"
#include "newgrf_town.h"
#include "timer/timer_game_tick.h"

#include "safeguards.h"

template <typename Tproj>
static uint16_t TownHistoryHelper(const Town *t, CargoLabel label, uint period, Tproj proj)
{
	auto it = t->GetCargoSupplied(GetCargoTypeByLabel(label));
	if (it == std::end(t->supplied)) return 0;

	return ClampTo<uint16_t>(std::invoke(proj, it->history[period]));
}

/* virtual */ uint32_t TownScopeResolver::GetVariable(uint8_t variable, [[maybe_unused]] uint32_t parameter, bool &available) const
{
	if (this->t == nullptr) {
		available = false;
		return UINT_MAX;
	}

	switch (variable) {
		/* Larger towns */
		case 0x40:
			if (_settings_game.economy.larger_towns == 0) return 2;
			if (this->t->larger_town) return 1;
			return 0;

		/* Town index */
		case 0x41: return this->t->index.base();

		/* Get a variable from the persistent storage */
		case 0x7C: {
			/* Check the persistent storage for the GrfID stored in register 100h. */
			uint32_t grfid = static_cast<uint32_t>(this->ro.GetRegister(0x100));
			if (grfid == 0xFFFFFFFF) {
				if (this->ro.grffile == nullptr) return 0;
				grfid = this->ro.grffile->grfid;
			}

			for (auto &it : this->t->psa_list) {
				if (it->grfid == grfid) return it->GetValue(parameter);
			}

			return 0;
		}

		/* Town properties */
		case 0x80: return this->t->xy.base();
		case 0x81: return GB(this->t->xy.base(), 8, 8);
		case 0x82: return ClampTo<uint16_t>(this->t->cache.population);
		case 0x83: return GB(ClampTo<uint16_t>(this->t->cache.population), 8, 8);
		case 0x8A: return this->t->grow_counter / Ticks::TOWN_GROWTH_TICKS;
		case 0x92: return this->t->flags.base(); // In original game, 0x92 and 0x93 are one word.
		case 0x93: return 0;
		case 0x94: return ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownEdge)]);
		case 0x95: return GB(ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownEdge)]), 8, 8);
		case 0x96: return ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownOutskirt)]);
		case 0x97: return GB(ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownOutskirt)]), 8, 8);
		case 0x98: return ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownOuterSuburb)]);
		case 0x99: return GB(ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownOuterSuburb)]), 8, 8);
		case 0x9A: return ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownInnerSuburb)]);
		case 0x9B: return GB(ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownInnerSuburb)]), 8, 8);
		case 0x9C: return ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownCentre)]);
		case 0x9D: return GB(ClampTo<uint16_t>(this->t->cache.squared_town_zone_radius[to_underlying(HouseZone::TownCentre)]), 8, 8);
		case 0x9E: return this->t->ratings[0];
		case 0x9F: return GB(this->t->ratings[0], 8, 8);
		case 0xA0: return this->t->ratings[1];
		case 0xA1: return GB(this->t->ratings[1], 8, 8);
		case 0xA2: return this->t->ratings[2];
		case 0xA3: return GB(this->t->ratings[2], 8, 8);
		case 0xA4: return this->t->ratings[3];
		case 0xA5: return GB(this->t->ratings[3], 8, 8);
		case 0xA6: return this->t->ratings[4];
		case 0xA7: return GB(this->t->ratings[4], 8, 8);
		case 0xA8: return this->t->ratings[5];
		case 0xA9: return GB(this->t->ratings[5], 8, 8);
		case 0xAA: return this->t->ratings[6];
		case 0xAB: return GB(this->t->ratings[6], 8, 8);
		case 0xAC: return this->t->ratings[7];
		case 0xAD: return GB(this->t->ratings[7], 8, 8);
		case 0xAE: return this->t->have_ratings.base();
		case 0xB2: return this->t->statues.base();
		case 0xB6: return ClampTo<uint16_t>(this->t->cache.num_houses);
		case 0xB9: return this->t->growth_rate / Ticks::TOWN_GROWTH_TICKS;
		case 0xBA: return TownHistoryHelper(this->t, CT_PASSENGERS, THIS_MONTH, &Town::SuppliedHistory::production);
		case 0xBB: return TownHistoryHelper(this->t, CT_PASSENGERS, THIS_MONTH, &Town::SuppliedHistory::production) >> 8;
		case 0xBC: return TownHistoryHelper(this->t, CT_MAIL, THIS_MONTH, &Town::SuppliedHistory::production);
		case 0xBD: return TownHistoryHelper(this->t, CT_MAIL, THIS_MONTH, &Town::SuppliedHistory::production) >> 8;
		case 0xBE: return TownHistoryHelper(this->t, CT_PASSENGERS, THIS_MONTH, &Town::SuppliedHistory::transported);
		case 0xBF: return TownHistoryHelper(this->t, CT_PASSENGERS, THIS_MONTH, &Town::SuppliedHistory::transported) >> 8;
		case 0xC0: return TownHistoryHelper(this->t, CT_MAIL, THIS_MONTH, &Town::SuppliedHistory::transported);
		case 0xC1: return TownHistoryHelper(this->t, CT_MAIL, THIS_MONTH, &Town::SuppliedHistory::transported) >> 8;
		case 0xC2: return TownHistoryHelper(this->t, CT_PASSENGERS, LAST_MONTH, &Town::SuppliedHistory::production);
		case 0xC3: return TownHistoryHelper(this->t, CT_PASSENGERS, LAST_MONTH, &Town::SuppliedHistory::production) >> 8;
		case 0xC4: return TownHistoryHelper(this->t, CT_MAIL, LAST_MONTH, &Town::SuppliedHistory::production);
		case 0xC5: return TownHistoryHelper(this->t, CT_MAIL, LAST_MONTH, &Town::SuppliedHistory::production) >> 8;
		case 0xC6: return TownHistoryHelper(this->t, CT_PASSENGERS, LAST_MONTH, &Town::SuppliedHistory::transported);
		case 0xC7: return TownHistoryHelper(this->t, CT_PASSENGERS, LAST_MONTH, &Town::SuppliedHistory::transported) >> 8;
		case 0xC8: return TownHistoryHelper(this->t, CT_MAIL, LAST_MONTH, &Town::SuppliedHistory::transported);
		case 0xC9: return TownHistoryHelper(this->t, CT_MAIL, LAST_MONTH, &Town::SuppliedHistory::transported) >> 8;
		case 0xCA: return this->t->GetPercentTransported(GetCargoTypeByLabel(CT_PASSENGERS));
		case 0xCB: return this->t->GetPercentTransported(GetCargoTypeByLabel(CT_MAIL));
		case 0xCC: return this->t->received[TAE_FOOD].new_act;
		case 0xCD: return GB(this->t->received[TAE_FOOD].new_act, 8, 8);
		case 0xCE: return this->t->received[TAE_WATER].new_act;
		case 0xCF: return GB(this->t->received[TAE_WATER].new_act, 8, 8);
		case 0xD0: return this->t->received[TAE_FOOD].old_act;
		case 0xD1: return GB(this->t->received[TAE_FOOD].old_act, 8, 8);
		case 0xD2: return this->t->received[TAE_WATER].old_act;
		case 0xD3: return GB(this->t->received[TAE_WATER].old_act, 8, 8);
		case 0xD4: return this->t->road_build_months;
		case 0xD5: return this->t->fund_buildings_months;
	}

	Debug(grf, 1, "Unhandled town variable 0x{:X}", variable);

	available = false;
	return UINT_MAX;
}

/* virtual */ void TownScopeResolver::StorePSA(uint pos, int32_t value)
{
	if (this->readonly) return;

	assert(this->t != nullptr);
	/* We can't store anything if the caller has no #GRFFile. */
	if (this->ro.grffile == nullptr) return;

	/* Check the persistent storage for the GrfID stored in register 100h. */
	uint32_t grfid = static_cast<uint32_t>(this->ro.GetRegister(0x100));

	/* A NewGRF can only write in the persistent storage associated to its own GRFID. */
	if (grfid == 0xFFFFFFFF) grfid = this->ro.grffile->grfid;
	if (grfid != this->ro.grffile->grfid) return;

	/* Check if the storage exists. */
	for (auto &it : t->psa_list) {
		if (it->grfid == grfid) {
			it->StoreValue(pos, value);
			return;
		}
	}

	/* Create a new storage. */
	assert(PersistentStorage::CanAllocateItem());
	PersistentStorage *psa = new PersistentStorage(grfid, GSF_FAKE_TOWNS, this->t->xy);
	psa->StoreValue(pos, value);
	t->psa_list.push_back(psa);
}

/**
 * Resolver for a town.
 * @param grffile NewGRF file associated with the town.
 * @param t %Town of the scope.
 * @param readonly Scope may change persistent storage of the town.
 */
TownResolverObject::TownResolverObject(const struct GRFFile *grffile, Town *t, bool readonly)
		: ResolverObject(grffile), town_scope(*this, t, readonly)
{
}

