# Tamil Nadu Transport Tycoon — OpenTTD 15.3 Android Port Workspace v6

Target package: `com.tamilnadutransporttycoon.game`
Target ABI: `arm64-v8a`
Target Android: Android 16 / API 36
Engine foundation: OpenTTD 15.3

## Status
This is a **source/build workspace, not an APK**. The community Android repository is an older Android fork, while OpenTTD 15.3 is newer. A real 15.3 Android build needs the Android-specific port layer brought forward and then compiled with Android SDK/NDK.

This package deliberately does not contain a falsely labelled or repacked APK.
