# Build status
- [x] OpenTTD 15.3 source included
- [x] Package ID selected: com.tamilnadutransporttycoon.game
- [x] ABI selected: arm64-v8a
- [x] Android API target: 36
- [ ] Android port integration for OpenTTD 15.3
- [ ] Native ARM64 compilation
- [ ] APK packaging/signing
- [ ] Installation test on Redmi 15A 5G / Android 16
- [ ] Tamil Nadu NewGRF/content integration
