/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file object_widget.h Types related to the object widgets. */

#ifndef WIDGETS_OBJECT_WIDGET_H
#define WIDGETS_OBJECT_WIDGET_H

/** Widgets of the #BuildObjectWindow class. */
enum BuildObjectWidgets : WidgetID {
	WID_BO_OBJECT_MATRIX,  ///< The matrix with preview sprites.
	WID_BO_OBJECT_SPRITE,  ///< A preview sprite of the object.
	WID_BO_OBJECT_SIZE,    ///< The size of the selected object.
	WID_BO_INFO,           ///< Other information about the object (from the NewGRF).
};

#endif /* WIDGETS_OBJECT_WIDGET_H */
